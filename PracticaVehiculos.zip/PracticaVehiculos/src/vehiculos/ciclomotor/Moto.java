package vehiculos.ciclomotor;

import java.util.Objects;

public class Moto extends Ciclomotor{
	
	private String tipo;



	public Moto(String marca, String modelo, String matricula, double cilindrada, String tipo) {
		super(marca, modelo, matricula, cilindrada);
		this.tipo = tipo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return String.format("Moto --> [ Marca = %s || Modelo = %s || Matrícula = %s || Tipo = %s]", this.getMarca(), this.getModelo(), this.getMatricula(),this.getTipo());
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moto other = (Moto) obj;
		return Objects.equals(tipo, other.tipo);
	}

	@Override
	public void acelerar() {
		System.out.println("Este vehículo alcanza los 50 km/h en 15 segundos");
		
	}
	
	
	
}
